package com.example.isport1.Remote

import com.example.isport1.Model.APIResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface IMyAPI {
    @FormUrlEncoded
    @POST("recutente.php")
    fun registerUser(@Field("username") username:String,@Field("password") Password:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("recadmin.php")
    fun registerAdmin(@Field("username") username:String,@Field("password") Password:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("login_user.php")
    fun login_user(@Field("username") username:String,@Field("password") Password:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("login_admin.php")
    fun login_admin(@Field("username") username:String,@Field("password") Password:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("Query_esempio.php")
    fun query_esempio(@Field("username") username:String,@Field("password") Password:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("insert_campo.php")
    fun insert_campo(@Field("provincia") provincia:String,@Field("comune") comune:String,@Field("indirizzo") indirizzo:String,@Field("admin_campo") admin_campo:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("search_campo.php")
    fun search_campo(@Field("provincia") provincia:String,@Field("comune") comune:String,@Field("indirizzo") indirizzo:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("insert_prenotazione.php")
    fun insert_prenotazione(@Field("id_campo") id_campo:Int,@Field("mese") mese:Int,@Field("giorno") giorno:Int,@Field("ora") ora:Int,@Field("username_giocatore") username_giocatore:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("search_prenoationByUsername.php")
    fun search_prenoationByUsername(@Field("username_giocatore") username_giocatore:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("delete_prenotationByUsername.php")
    fun delete_prenotationByUsername(@Field("id_prenotazione") id_prenotazione:Int): Call<APIResponse>

    @FormUrlEncoded
    @POST("search_campo_by_admin.php")
    fun search_campo_by_admin(@Field("username_admin") username_admin:String): Call<APIResponse>

    @FormUrlEncoded
    @POST("delete_campo.php")
    fun delete_campo(@Field("id_campo") id_campo:Int): Call<APIResponse>

    @FormUrlEncoded
    @POST("search_prenot_by_id_campo.php")
    fun search_prenot_by_id_campo(@Field("id_campo") id_campo:Int): Call<APIResponse>


}