package com.example.isport1

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.example.isport1.Common.Common
import com.example.isport1.Model.APIResponse
import com.example.isport1.Model.Prenotazioni
import com.example.isport1.Remote.IMyAPI
import retrofit2.Call
import retrofit2.Response

class Delete_prenotation_Activity : AppCompatActivity() {
    internal lateinit var mService: IMyAPI
    lateinit var prenotati:Array<Prenotazioni>
    override fun onCreate(savedInstanceState: Bundle?) {
        val actionBar = supportActionBar
        actionBar!!.title = "ELIMINA PRENOTAZIONE"
        actionBar.setDisplayHomeAsUpEnabled(true)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_prenotation)
        val listView = findViewById<ListView>(R.id.listview)
        mService = Common.api


        val username_giocatore=intent.getStringExtra("id")

        mService.search_prenoationByUsername(username_giocatore!!).enqueue(object : retrofit2.Callback<APIResponse> {
            override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                if (response!!.body()!!.error) {
                    println(response.body()!!.error_msg)
                    Toast.makeText(
                        this@Delete_prenotation_Activity,
                        "NON CI SONO CAMPI DISPONIBILI",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    println(response!!.body()!!.prenotazioni!!)
                    prenotati = response!!.body()!!.prenotazioni!!
                    stampa(prenotati)
                }
            }

            override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                Toast.makeText(this@Delete_prenotation_Activity, t!!.message, Toast.LENGTH_SHORT).show()
                println(t!!.message)
            }
        })
        Toast.makeText(this@Delete_prenotation_Activity, "HAI SELEZIONATO CONFERMA", Toast.LENGTH_SHORT).show()


    }
    private fun stampa(pippo:Array<Prenotazioni>) {
        val listView = findViewById<ListView>(R.id.listview)
        var lunghezza=pippo.size
        var prov = Array<String?>(lunghezza){""}
        var com = Array<String?>(lunghezza){""}
        var ind = Array<String?>(lunghezza){""}
        var mese = Array<String?>(lunghezza){""}
        var giorno = Array<String?>(lunghezza){""}
        var ora = Array<String?>(lunghezza){""}
        var id_pren = arrayOfNulls<Int>(lunghezza)

        var ris = Array<String?>(lunghezza){""}
        var indix:Int = 0
        while(indix<lunghezza) {
            prov[indix] = pippo[indix].provincia.toString()
            com[indix] = pippo[indix].comune.toString()
            ind[indix] = pippo[indix].indirizzo.toString()
            mese[indix] =pippo[indix].mese.toString()
            giorno[indix] =pippo[indix].giorno.toString()
            ora[indix] =pippo[indix].ora.toString()
            id_pren[indix]=pippo[indix].id_prenotazione
            ris[indix]=prov[indix]+"     "+com[indix]+"      "+ind[indix]+"      "+mese[indix]+"      "+giorno[indix]+"      "+ora[indix]
            indix +=1
        }


        val arrayAdapter: ArrayAdapter<String> = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,ris
        )

        listView.adapter = arrayAdapter

        listView.setOnItemClickListener { adapterView, view, i, l ->
            dialog(i,id_pren)
        }

    }
    @SuppressLint("SuspiciousIndentation")
    private fun dialog(pos:Int, array_pren:Array<Int?>) {
        val dialogBinding = layoutInflater.inflate(R.layout.my_custom_dialog_delete,null)

        val myDialog = Dialog(this)
        myDialog.setContentView(dialogBinding)

        myDialog.setCancelable(true)
        myDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        myDialog.show()

        val yesbtn = dialogBinding.findViewById<View>(R.id.bottone_conferma)
        yesbtn.setOnClickListener {


                        mService.delete_prenotationByUsername(array_pren[pos]!!).enqueue(object : retrofit2.Callback<APIResponse> {
                            override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                            }

                            override fun onFailure(call: Call<APIResponse>, t: Throwable) {

                            }
                        })
                        Toast.makeText(this@Delete_prenotation_Activity, "HAI ELIMINATO LA PRENOTAZIONE     PER VISIONARE LA CANCELLAZIONE AGGIORNA", Toast.LENGTH_SHORT).show()
                        myDialog.dismiss()
        }

    }
    }
