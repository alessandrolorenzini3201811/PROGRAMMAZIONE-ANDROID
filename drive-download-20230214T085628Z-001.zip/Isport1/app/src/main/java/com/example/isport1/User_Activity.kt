package com.example.isport1

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import android.window.SplashScreen
import androidx.core.view.get
import androidx.fragment.app.Fragment
import com.example.isport1.Common.Common
import com.example.isport1.Model.APIResponse
import com.example.isport1.Model.Admin
import com.example.isport1.Model.Campo
import com.example.isport1.Model.User
import com.example.isport1.Remote.IMyAPI
import com.example.isport1.databinding.ActivityMainBinding
import com.example.isport1.databinding.ActivityUserBinding

import org.w3c.dom.Text
import retrofit2.Call
import retrofit2.Response

class User_Activity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var tipi: String
    lateinit var spinner: Spinner
    internal lateinit var mService: IMyAPI
    private lateinit var binding: ActivityUserBinding
    var data = arrayOf("", "", "")
    lateinit var campo: Array<Campo>
    var id_sp1:Int=0
    var id_sp2:Int=0
    var id_sp3:Int=0


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.title = "HOME GIOCATORE"

        mService = Common.api
        binding.listview.isClickable = true
        binding.insert.setOnClickListener {

            search_campo_fun()
        }

        binding.modify.setOnClickListener {
            val intento = Intent(this, Delete_prenotation_Activity::class.java)
            val username_giocatore=intent.getStringExtra("id")
            intento.putExtra("id", username_giocatore)
            startActivity(intento)
        }

    }


    private fun search_campo_fun(){
        val provincia=binding.provincia.text.toString()
        val comune=binding.comune.text.toString()
        val indirizzo=binding.indirizzo.text.toString()
        var prov:Array<String>

        mService.search_campo(provincia, comune, indirizzo)
            .enqueue(object : retrofit2.Callback<APIResponse> {
                override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                    if (response!!.body()!!.error) {
                        println(response.body()!!.error_msg)
                        Toast.makeText(
                            this@User_Activity,
                            "NON CI SONO CAMPI DISPONIBILI",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        campo = response!!.body()!!.campo!!

                        stampa(campo)
                    }
                }

                override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                    Toast.makeText(this@User_Activity, t!!.message, Toast.LENGTH_SHORT).show()
                }

            })


    }

    private fun stampa(risposta:Array<Campo>) {
        val listView = findViewById<ListView>(R.id.listview)
        var lunghezza=risposta.size
        var prov = Array<String?>(lunghezza){""}
        var com = Array<String?>(lunghezza){""}
        var ind = Array<String?>(lunghezza){""}
        var id_campos =Array<String?>(lunghezza){""}
        var ris = Array<String?>(lunghezza){""}
        var indix:Int = 0
        while(indix<lunghezza) {
            prov[indix] = risposta[indix].provincia.toString()
            com[indix] = risposta[indix].comune.toString()
            ind[indix] = risposta[indix].indirizzo.toString()
            id_campos[indix]=risposta[indix].id_campo.toString()
            ris[indix]=prov[indix]+"     "+com[indix]+"      "+ind[indix]
            indix +=1
        }


        val arrayAdapter: ArrayAdapter<String> = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,ris
        )

        listView.adapter = arrayAdapter

        listView.setOnItemClickListener { adapterView, view, i, l ->
            dialog(i,id_campos)

        }

    }

    @SuppressLint("SuspiciousIndentation", "ResourceType")
    private fun dialog(pos:Int,id_camposa:Array<String?>) {
        val dialogBinding = layoutInflater.inflate(R.layout.my_custom_dialog,null)

        val myDialog = Dialog(this)
        myDialog.setContentView(dialogBinding)

        myDialog.setCancelable(true)
        myDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))


        val spinner1 = myDialog.findViewById<Spinner>(R.id.Spinner1)
        val arrayAdapter: ArrayAdapter<CharSequence> = ArrayAdapter.createFromResource(
            this,
            R.array.mese, android.R.layout.simple_spinner_item
        )
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
        spinner1.adapter = arrayAdapter
        spinner1.onItemSelectedListener = this
        id_sp1=spinner1.id
        val spinner2 = myDialog.findViewById<Spinner>(R.id.Spinner2)
        val arrayAdapter2: ArrayAdapter<CharSequence> = ArrayAdapter.createFromResource(
            this,
            R.array.giorno, android.R.layout.simple_spinner_item
        )
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
        spinner2.adapter = arrayAdapter2
        spinner2.onItemSelectedListener = this
        id_sp2=spinner2.id
        val spinner3 = myDialog.findViewById<Spinner>(R.id.Spinner3)
        val arrayAdapter3: ArrayAdapter<CharSequence> = ArrayAdapter.createFromResource(
            this,
            R.array.ora, android.R.layout.simple_spinner_item
        )
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
        spinner3.adapter = arrayAdapter3
        spinner3.onItemSelectedListener = this
        id_sp3=spinner3.id
        myDialog.show()


        val yesbtn = dialogBinding.findViewById<View>(R.id.bottone_conferma)
        yesbtn.setOnClickListener {
            val username_giocatore=intent.getStringExtra("id")
            val d1=data[0].toInt()
            val d2=data[1].toInt()
            val d3=data[2].toInt()
            if(d1==0 || d2==0 || d3==0){
                Toast.makeText(this@User_Activity, "INSERISCI LA DATA CORRETTAMENTE", Toast.LENGTH_SHORT).show()
            }else {
                mService.insert_prenotazione(
                    id_camposa[pos]!!.toInt(),
                    d1,
                    d2,
                    d3,
                    username_giocatore!!
                ).enqueue(object : retrofit2.Callback<APIResponse> {
                    override fun onResponse(
                        call: Call<APIResponse>,
                        response: Response<APIResponse>
                    ) {
                        if (response.body()!!.error) {
                            Toast.makeText(
                                this@User_Activity,
                                "IL CAMPO E' GIA' STATO PRENOTATO",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@User_Activity,
                                "LA PRENOTAZIONE E' ANDATA A BUON FINE",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                        Toast.makeText(this@User_Activity, t!!.message, Toast.LENGTH_SHORT).show()

                    }
                })
            }
            myDialog.dismiss()
        }

    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        if (parent!!.id == id_sp1) {
            var a: String = parent.getItemAtPosition(position).toString()
            if(a!="MESE")
            data[0] = a
            else
                data[0] = "0"

        } else if (parent!!.id == id_sp2) {
            var a: String = parent.getItemAtPosition(position).toString()
            if(a!="GIORNO")
            data[1] = a
            else
                data[1] = "0"
        } else if (parent!!.id ==id_sp3 ) {
            var a: String = parent.getItemAtPosition(position).toString()
            if(a!="ORA")
            data[2] = a
            else
                data[2] = "0"

        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }

}