package com.example.isport1.Model

class APIResponse {
    var error:Boolean=false
    var error_msg:String?=null
    var table:Admin?=null
    var user:User?=null
    var admin:Admin?=null
    var campo:Array<Campo>?=null
    var prenotazioni:Array<Prenotazioni>?=null
}