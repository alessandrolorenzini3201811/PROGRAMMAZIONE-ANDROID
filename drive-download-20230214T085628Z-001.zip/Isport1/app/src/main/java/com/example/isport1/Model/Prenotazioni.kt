package com.example.isport1.Model

class Prenotazioni {

    var provincia:String?=""
    var comune:String?=""
    var indirizzo:String?=""
    var mese:Int?=null
    var giorno:Int?=null
    var ora:Int?=null
    var id_prenotazione:Int?=null
    var id_campo:Int?=null
}