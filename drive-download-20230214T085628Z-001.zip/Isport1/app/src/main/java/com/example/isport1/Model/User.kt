package com.example.isport1.Model

class User {
   var Username:String?=""
   var Password:String?=""
}