package com.example.isport1

import android.annotation.SuppressLint
import android.content.Intent
import android.net.DnsResolver.Callback
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import com.example.isport1.Common.Common
import com.example.isport1.Model.APIResponse
import com.example.isport1.Model.Admin
import com.example.isport1.Model.User
import com.example.isport1.Remote.IMyAPI
import com.example.isport1.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Response
import java.lang.NullPointerException

class MainActivity : AppCompatActivity() {
    lateinit var tipi: String
    lateinit var spinner: Spinner
    internal lateinit var mService: IMyAPI
    private lateinit var binding: ActivityMainBinding

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.title = " ISPORT"
        var utente = arrayOf("Amministratore", "Giocatore")
        spinner = findViewById<Spinner>(R.id.Spinner2) as Spinner
        spinner.adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, utente)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                tipi = utente.get(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                Toast.makeText(this@MainActivity, "Insrito", Toast.LENGTH_SHORT)
                    .show()
            }


        }


        mService = Common.api


        binding.insert.setOnClickListener {
            if (tipi == "Giocatore")
                createRecUser()
            else if (tipi == "Amministratore")
                createRecAdmin()
            else
                Toast.makeText(
                    this@MainActivity,
                    "INSERISCI CHE RUOLO VUOI AVERE",
                    Toast.LENGTH_SHORT
                ).show()
        }

        binding.login.setOnClickListener {
            if (tipi == "Giocatore")
                checklogin_user()

            else if (tipi == "Amministratore"){
                checklogin_admin()

            }
            else
                Toast.makeText(
                    this@MainActivity,
                    "INSERISCI CHE RUOLO VUOI AVERE",
                    Toast.LENGTH_SHORT
                ).show()
        }

    }

    private fun checklogin_admin() {
        val intent = Intent(this, Admin_Activity::class.java)
        var username = binding.email.text.toString()
        var password = binding.password.text.toString()

        mService.login_admin(username, password).enqueue(object : retrofit2.Callback<APIResponse> {
            override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {

                var admin:Admin

                if (response!!.body()!!.error) {
                    println(response.body()!!.error_msg)
                    Toast.makeText(
                        this@MainActivity,
                        "CREDENZIALI SBAGLIATE",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {

                    admin= response!!.body()!!.admin!!
                    Toast.makeText(this@MainActivity, "CREDENZIALI CORRETTE", Toast.LENGTH_SHORT)
                        .show()
                    Toast.makeText(this@MainActivity,admin.username_admin, Toast.LENGTH_SHORT).show()
                    intent.putExtra("id",admin.username_admin)
                    startActivity(intent)
                    //Toast.makeText(this@MainActivity,utente[1][1], Toast.LENGTH_SHORT).show()
                    finish()
                }
            }

            override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "CREDENZIALI CORRETTE", Toast.LENGTH_SHORT)
                    .show()
            }

        })

    }

    private fun checklogin_user() {
        val intent = Intent(this, User_Activity::class.java)

        var username = binding.email.text.toString()
        var password = binding.password.text.toString()

        mService.login_user(username, password).enqueue(object : retrofit2.Callback<APIResponse> {
            override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                var utente: User
                if (response!!.body()!!.error) {
                    println(response.body()!!.error_msg)
                    Toast.makeText(
                        this@MainActivity,
                        "CREDENZIALI SBAGLIATE",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    utente= response!!.body()!!.user!!
                    Toast.makeText(this@MainActivity, "CREDENZIALI CORRETTE", Toast.LENGTH_SHORT)
                        .show()
                    intent.putExtra("id",utente.Username)
                    startActivity(intent)

                    finish()
                }
            }

            override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "CREDENZIALI SBAGLIATE", Toast.LENGTH_SHORT).show()
            }

        })

    }

    private fun createRecAdmin() {
        var username = binding.email.text.toString()
        var password = binding.password.text.toString()

        if (username.isNotEmpty() && password.isNotEmpty()) {
            Toast.makeText(this@MainActivity, username, Toast.LENGTH_SHORT).show()
            mService.registerAdmin(username, password)
                .enqueue(object : retrofit2.Callback<APIResponse> {
                    override fun onResponse(
                        call: Call<APIResponse>,
                        response: Response<APIResponse>
                    ) {
                        if (response!!.body()!!.error) {
                            println(response.body()!!.error_msg)
                            Toast.makeText(
                                this@MainActivity,
                                "RIGISTRAZIONE EFFETTUATA",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                response.body()!!.error_msg,
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    }

                    override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                        Toast.makeText(this@MainActivity, t!!.message, Toast.LENGTH_SHORT).show()
                        println(t!!.message)
                    }

                })
        } else {
            Toast.makeText(this@MainActivity, "INSERISCI TUTTI I CAMPI", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createRecUser() {
        var username = binding.email.text.toString()
        var password = binding.password.text.toString()
        if (username.isNotEmpty() && password.isNotEmpty()) {
            mService.registerUser(username, password)
                .enqueue(object : retrofit2.Callback<APIResponse> {
                    override fun onResponse(
                        call: Call<APIResponse>,
                        response: Response<APIResponse>
                    ) {
                        if (response!!.body()!!.error) {
                            println(response.body()!!.error_msg)
                            Toast.makeText(
                                this@MainActivity,
                                "RIGISTRAZIONE EFFETTUATA",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                response.body()!!.error_msg,
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    }

                    override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                        Toast.makeText(this@MainActivity, t!!.message, Toast.LENGTH_SHORT).show()
                        println(t!!.message)
                    }

                })
        } else {
            Toast.makeText(this@MainActivity, "INSERISCI TUTTI I CAMPI", Toast.LENGTH_SHORT).show()
        }
    }

}
