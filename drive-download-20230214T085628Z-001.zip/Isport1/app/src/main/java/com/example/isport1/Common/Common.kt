package com.example.isport1.Common

import com.example.isport1.Remote.IMyAPI
import com.example.isport1.Remote.RetrofitClient

object Common {
    val BASE_URL = "http://10.0.2.2/query/"

    val api:IMyAPI
        get() = RetrofitClient.getClient(BASE_URL).create(IMyAPI::class.java)
}