package com.example.isport1

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Spinner
import android.widget.Toast
import com.example.isport1.Common.Common
import com.example.isport1.Model.APIResponse
import com.example.isport1.Model.Admin
import com.example.isport1.Remote.IMyAPI
import com.example.isport1.databinding.ActivityAdminBinding
import com.example.isport1.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Response

class Admin_Activity : AppCompatActivity() {
    lateinit var tipi: String
    lateinit var spinner: Spinner
    internal lateinit var mService: IMyAPI
    private lateinit var binding: ActivityAdminBinding

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.title = "HOME ADMIN"
        mService = Common.api
        val admin_campo=intent.getStringExtra("id")
        binding.insert.setOnClickListener {

            if (admin_campo != null) {
                insert_campo_fun(admin_campo)
            }
        }
        binding.modify.setOnClickListener {
            val intento = Intent(this, DelMod_campo_Activity::class.java)
            intento.putExtra("id", admin_campo)
            startActivity(intento)

        }
    }
    private fun insert_campo_fun(admin_campo:String): Boolean {
        val provincia=binding.provincia.text.toString()
        val comune=binding.comune.text.toString()
        val indirizzo=binding.indirizzo.text.toString()
        Toast.makeText(
            this@Admin_Activity,
            provincia,
            Toast.LENGTH_SHORT
        ).show()
        mService.insert_campo(provincia,comune,indirizzo,admin_campo).enqueue(object : retrofit2.Callback<APIResponse> {
            override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                if(response!!.body()!!.error) {
                    Toast.makeText(
                        this@Admin_Activity,
                        "INSERISCI CORRETTAMENTE I DATI",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                Toast.makeText(this@Admin_Activity, t!!.message, Toast.LENGTH_SHORT).show()
            }
        })
        return true
    }

}