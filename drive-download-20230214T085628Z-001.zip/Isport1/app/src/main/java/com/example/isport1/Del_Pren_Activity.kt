package com.example.isport1

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.example.isport1.Common.Common
import com.example.isport1.Model.APIResponse
import com.example.isport1.Model.Campo
import com.example.isport1.Model.Prenotazioni
import com.example.isport1.Remote.IMyAPI
import com.example.isport1.databinding.ActivityDelModCampoBinding
import retrofit2.Call
import retrofit2.Response

class Del_Pren_Activity : AppCompatActivity() {

    internal lateinit var mService: IMyAPI
    private lateinit var binding: ActivityDelModCampoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        val id_campi = intent.getStringExtra("id_campo")
        val actionBar = supportActionBar
        actionBar!!.title = "ELIMINA PRENOTAZIONE"
        actionBar.setDisplayHomeAsUpEnabled(true)

        binding = ActivityDelModCampoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_del_pren)

        var risposta: Array<Prenotazioni>

        mService = Common.api

        mService.search_prenot_by_id_campo(id_campi!!.toInt() )
            .enqueue(object : retrofit2.Callback<APIResponse> {
                override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                    if (response!!.body()!!.error) {
                        println(response.body()!!.error_msg)
                        Toast.makeText(
                            this@Del_Pren_Activity,
                            "NON CI SONO CAMPI DISPONIBILI",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        risposta = response!!.body()!!.prenotazioni!!
                        var lunghezza = risposta.size
                        var prov = Array<String?>(lunghezza) { "" }
                        var com = Array<String?>(lunghezza) { "" }
                        var ind = Array<String?>(lunghezza) { "" }
                        var mese = Array<String?>(lunghezza){""}
                        var giorno = Array<String?>(lunghezza){""}
                        var ora = Array<String?>(lunghezza){""}
                        var id_pren = arrayOfNulls<Int>(lunghezza)
                        var id_prenotazioni = Array<String?>(lunghezza) { "" }
                        var ris = Array<String?>(lunghezza) { "" }
                        var indix: Int = 0
                        while (indix < lunghezza) {
                            prov[indix] = risposta[indix].provincia.toString()
                            com[indix] = risposta[indix].comune.toString()
                            ind[indix] = risposta[indix].indirizzo.toString()
                            mese[indix] =risposta[indix].mese.toString()
                            giorno[indix] =risposta[indix].giorno.toString()
                            ora[indix] =risposta[indix].ora.toString()
                            id_prenotazioni[indix] = risposta[indix].id_prenotazione.toString()
                            ris[indix] = prov[indix] + "     " + com[indix] + "      " + ind[indix]+"      "+mese[indix]+"      "+giorno[indix]+"      "+ora[indix]
                            indix += 1


                        }
                        stampa(ris, id_prenotazioni)
                    }
                }

                override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                }

            })


    }

    private fun stampa(risp: Array<String?>, id_campo: Array<String?>) {
        val arrayAdapter: ArrayAdapter<String> = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1, risp
        )
        val listView = findViewById<ListView>(R.id.listview)
        listView.adapter = arrayAdapter

        listView.setOnItemClickListener { adapterView, view, i, l ->
            dialog(i, id_campo)

        }
    }

    @SuppressLint("SuspiciousIndentation", "ResourceType", "MissingInflatedId")
    private fun dialog(pos: Int, id_camposa: Array<String?>) {
        val dialogBinding = layoutInflater.inflate(R.layout.my_custom_dialog_delmod_pren, null)

        val myDialog = Dialog(this)
        myDialog.setContentView(dialogBinding)

        myDialog.setCancelable(true)
        myDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        myDialog.show()

        val yesbtn = dialogBinding.findViewById<View>(R.id.elimina_prenotazione)
        yesbtn.setOnClickListener {
            //ELIMINARE CAMPO
            Toast.makeText(this@Del_Pren_Activity, "hai cliccato el elimina", Toast.LENGTH_SHORT).show()
            println(id_camposa[pos]!!.toInt())
            mService.delete_prenotationByUsername(id_camposa[pos]!!.toInt()).enqueue(object : retrofit2.Callback<APIResponse> {
                override fun onResponse(call: Call<APIResponse>, response: Response<APIResponse>) {
                    if (response!!.body()!!.error) {
                        println(response.body()!!.error_msg)
                        Toast.makeText(
                            this@Del_Pren_Activity,
                            "NON CI SONO CAMPI DISPONIBILI",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                override fun onFailure(call: Call<APIResponse>, t: Throwable) {
                    Toast.makeText(this@Del_Pren_Activity, t!!.message, Toast.LENGTH_SHORT).show()
                }

            })
            myDialog.dismiss()

        }


    }
}

