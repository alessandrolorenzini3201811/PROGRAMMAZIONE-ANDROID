package com.example.isport1.Model

class Admin {
    var username_admin:String?=""
    var password_admin:String?=""
}