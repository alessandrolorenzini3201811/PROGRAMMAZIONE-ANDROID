package com.example.isport1.Model

class Campo {
    var id_campo:Int?=null
    var provincia:String?=""
    var comune:String?=""
    var indirizzo:String?=""
    var admin_campo:String?=""
}