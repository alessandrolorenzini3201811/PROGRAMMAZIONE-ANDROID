<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$username1=$_POST['username'];
$password1=$_POST['password'];
if($username1!=null and $password1!=null){
	$responce["error"]=FALSE;
	$insert = "INSERT INTO admin(Username_admin, Password_admin) VALUES('$username1','$password1')";
}else{
	$responce["error"]=TRUE;
}
$result_insert = $conn->query($insert);

$conn->close();

?>