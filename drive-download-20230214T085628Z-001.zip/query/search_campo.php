<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$provincia1=$_POST['provincia'];
$comune1=$_POST['comune'];
$indirizzo1=$_POST['indirizzo'];

if($provincia1==null && $comune1==null && $indirizzo1==null)
									$search = "	SELECT id_campo,provincia,comune,indirizzo
									FROM campo";
else if ($comune1==null && $indirizzo1==null)
			$search = "	SELECT id_campo,provincia,comune,indirizzo
			FROM campo 
			WHERE provincia LIKE '$provincia1'";

	else if($comune1!=null&& $indirizzo1==null)		
			$search = "	SELECT id_campo,provincia,comune,indirizzo
			FROM campo 
			WHERE provincia LIKE '$provincia1' AND comune LIKE '$comune1'";

			else if($comune1==null&& $indirizzo1!=null)
					$search = "	SELECT id_campo,provincia,comune,indirizzo
			FROM campo 
			WHERE provincia LIKE '$provincia1' AND indirizzo LIKE '$indirizzo1'";

					else if($provincia1!=null && $comune1!=null && $indirizzo1!=null)
						$search = "	SELECT id_campo,provincia,comune,indirizzo
									FROM campo 
									WHERE provincia LIKE '$provincia1' AND comune LIKE '$comune1' AND indirizzo LIKE '$indirizzo1'";
								
							


$result_search = $conn->query($search);

//$campo1=$result_search->fetch_all();
$emparray = array();
if($result_search->num_rows > 0){
	$responce["error"]=FALSE;
	//$responce["campo"]=$campo1;
	//echo json_encode($responce);
    while($row = mysqli_fetch_assoc($result_search))
    {
        $emparray[] = $row;
    }
    $responce["campo"]=$emparray;
	echo json_encode($responce);
}else{
	$responce["error"]=TRUE;
	$responce["error_msg"]= "NON CI SONO CAMPI";
	echo json_encode($responce);

}

$conn->close();

?>