<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$username1=$_POST['username_giocatore'];


$search = "	SELECT provincia,comune,indirizzo,mese,giorno,ora,id_prenotazione
			FROM prenotazionicampo NATURAL JOIN campo
			WHERE username_giocatore LIKE '$username1'";
						
	
		
$result_search = $conn->query($search);

//$campo1=$result_search->fetch_all();
$emparray = array();
if($result_search->num_rows > 0){
	$responce["error"]=FALSE;
	//$responce["campo"]=$campo1;
	//echo json_encode($responce);
    while($row = mysqli_fetch_assoc($result_search))
    {
        $emparray[] = $row;
    }
    $responce["prenotazioni"]=$emparray;
	echo json_encode($responce);
}else{
	$responce["error"]=TRUE;
	$responce["error_msg"]= "NON CI SONO CAMPI";
	echo json_encode($responce);

}

$conn->close();

?>