<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id_campo1=$_POST['id_campo'];
$mese1=$_POST['mese'];
$giorno1=$_POST['giorno'];
$ora1=$_POST['ora'];
$username_giocatore=$_POST['username_giocatore'];

$query = "SELECT COUNT(*) as count FROM prenotazionicampo WHERE id_campo='$id_campo1' AND mese='$mese1' AND giorno='$giorno1' AND ora='$ora1'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

if ($row['count'] == 0) {
	$responce["error"]=FALSE;
	$insert = "INSERT INTO prenotazionicampo(id_prenotazione,id_campo,mese,giorno,ora,username_giocatore) VALUES('','$id_campo1','$mese1','$giorno1','$ora1','$username_giocatore')";
	$result_insert = $conn->query($insert);
	echo json_encode($responce);
}else{
	$responce["error"]=TRUE;
	echo json_encode($responce);
}

$conn->close();

?>