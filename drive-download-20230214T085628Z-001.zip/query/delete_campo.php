<?php
$servername = "localhost";
$username = "admin_sistemii";
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id_campo1=$_POST['id_campo'];


$delete = "	DELETE FROM campo
			WHERE id_campo = '$id_campo1'";

$result_search = $conn->query($delete);

?>