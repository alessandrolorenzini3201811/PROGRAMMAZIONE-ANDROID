<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$username1=$_POST['username'];
$password1=$_POST['password'];

$insert = "INSERT INTO user(Username, Password) VALUES('$username1','$password1')";

$result_insert = $conn->query($insert);

$conn->close();

?>