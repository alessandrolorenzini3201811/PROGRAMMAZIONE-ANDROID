<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$admin=$_POST['username_admin'];

$search="SELECT * FROM 	campo WHERE admin_campo LIKE '$admin'";

$result_search = $conn->query($search);

//$campo1=$result_search->fetch_all();
$emparray = array();
if($result_search->num_rows > 0){
	$responce["error"]=FALSE;
	//$responce["campo"]=$campo1;
	//echo json_encode($responce);
    while($row = mysqli_fetch_assoc($result_search))
    {
        $emparray[] = $row;
    }
    $responce["campo"]=$emparray;
	echo json_encode($responce);
}else{
	$responce["error"]=TRUE;
	$responce["error_msg"]= "NON CI SONO CAMPI";
	echo json_encode($responce);

}

$conn->close();

?>