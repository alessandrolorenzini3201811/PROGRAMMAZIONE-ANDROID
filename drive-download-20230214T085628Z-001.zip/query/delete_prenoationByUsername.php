<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id_pren1=$_POST['id_prenotazione'];


$delete = "	DELETE FROM prenotazionicampo
			WHERE id_prenotazione = '$id_pren1'";


if (mysqli_query($conn, $delete)) {
    if(mysqli_affected_rows($conn)>0)
      echo "Record eliminato correttamente";
    else
      echo "Nessun record trovato con l'id: ".$id_pren1;
} else {
    echo "Errore nell'eliminazione: " . mysqli_error($conn);
}
$conn->close();

?>