<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$username1=$_POST['username'];
$password1=$_POST['password'];

$select = "SELECT * FROM admin WHERE username_admin LIKE '$username1' AND password_admin LIKE '$password1'";

$result_select = $conn->query($select);

//echo $user1['username'];
$admin1=$result_select->fetch_assoc();
//$user2=$result_select->fetch_all();

if($result_select->num_rows > 0){
	
	$responce["error"]=FALSE;
	$responce["error_msg"]= "LOGIN CORRETTA";
	$responce["admin"]=$admin1;
	echo json_encode($responce);
	
}else{
	$responce["error"]=TRUE;
	$responce["error_msg"]= "LOGIN SBAGLIATA";
	echo json_encode($responce);

}

$conn->close();

?>