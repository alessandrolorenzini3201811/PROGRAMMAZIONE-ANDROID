<?php
$servername = "localhost";
$username = "admin_sistemii"; // dbuser e dbpassword impostate da phpmyadmin 
$password = "Admin123!";
$dbname="test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$provincia1=$_POST['provincia'];
$comune1=$_POST['comune'];
$indirizzo1=$_POST['indirizzo'];
$admin_campo1=$_POST['admin_campo'];


if($username1!=null and $password1!=null){
	$responce["error"]=FALSE;
	$insert = "INSERT INTO campo(id_campo,provincia,comune,indirizzo,admin_campo) VALUES('','$provincia1','$comune1','$indirizzo1','$admin_campo1')";
}else{
	$responce["error"]=TRUE;
}
$result_insert = $conn->query($insert);

$conn->close();

?>